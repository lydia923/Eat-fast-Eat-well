# Eat Fast, Eat Well

A minimalist recipe ebook for students looking to cook quick, affordable meals.  
This version is built in simple HTML and can be published via GitHub Pages.

## How to Publish with GitHub Pages

1. Upload all files from this repository to your GitHub repo.
2. Go to **Settings > Pages**.
3. Under **Source**, choose the `main` branch and `/root` folder.
4. Click Save – your site will be live at `https://<your-username>.github.io/<repo-name>/`.

## What's included
- `index.html` — full ebook in web format
- Clean layout with 25 recipes
- Lightweight, mobile-friendly
